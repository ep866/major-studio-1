function setup() {
}

function showData(data) {
}